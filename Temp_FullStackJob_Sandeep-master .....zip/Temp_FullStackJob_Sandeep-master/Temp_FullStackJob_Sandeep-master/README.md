# Silk Security Assessment For Opportunity  

## Badges

![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)

## Description

Use a sqlite database to create a collapsable table showing its data and a pie chart.

## Table of Contents
* [Badges](#badges)
* [Description](#description)
* [Installation](#installation)
* [Usage](#usage)
* [License](#license)
* [Contributing](#contributing)
* [Tests](#tests)


## Installation

Create a zip file of folder using Github Repo, open terminal and navigate into findings folder, type  npm i --legacy-peer-deps     then type npm start    


## Usage 



## License

MIT License

## Contributing
Sandeep Bisht

## Tests

N/A

[User Git Hub Link](https://github.com/Sandeep1138/assignment/ )

User Email: Sandeepbisht256@gmail.com
